export function Marquee() {
  const items = ["Crafted in Culture", "Powered by Color", "Future of Tradition", "Painted by Holi", "Designed in India"];
  return (
    <section className="relative py-10 border-y border-foreground/10 overflow-hidden bg-[oklch(0.12_0.10_300)]">
      <div className="flex gap-16 whitespace-nowrap animate-drift" style={{ width: "max-content" }}>
        {[...items, ...items, ...items].map((it, i) => (
          <span key={i} className="font-display italic text-5xl md:text-7xl text-gradient">
            {it} <span className="text-accent not-italic mx-6">✦</span>
          </span>
        ))}
      </div>
    </section>
  );
}
