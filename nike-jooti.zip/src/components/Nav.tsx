export function Nav() {
  return (
    <header className="fixed top-0 inset-x-0 z-50">
      <div className="mx-auto max-w-7xl px-6 lg:px-10 py-5 flex items-center justify-between glass rounded-b-2xl">
        <a href="#top" className="flex items-center gap-3">
          <span className="font-display text-2xl tracking-[0.25em] text-gold">NIKE</span>
          <span className="h-3 w-3 rounded-full bg-[oklch(0.65_0.31_340)] glow-pink" />
          <span className="font-display text-2xl tracking-[0.25em] text-gradient">JOOTI</span>
        </a>
        <nav className="hidden md:flex items-center gap-10 text-xs uppercase tracking-[0.3em] text-foreground/80">
          <a href="#drops" className="hover:text-accent transition-colors">Drops</a>
          <a href="#craft" className="hover:text-accent transition-colors">Craft</a>
          <a href="#campaign" className="hover:text-accent transition-colors">Campaign</a>
          <a href="#footer" className="hover:text-accent transition-colors">Contact</a>
        </nav>
        <button className="text-xs uppercase tracking-[0.3em] px-4 py-2 rounded-full border border-foreground/20 hover:border-accent hover:text-accent transition-colors">
          Drop · 03·06·26
        </button>
      </div>
    </header>
  );
}
