import violet from "@/assets/drop-violet.jpg";
import neon from "@/assets/drop-neon.jpg";
import phantom from "@/assets/drop-phantom.jpg";
import { PowderClouds } from "./PowderClouds";

const drops = [
  { name: "Violet Maharaja", code: "NJ·001", price: "₹ 48,000", img: violet, glow: "oklch(0.55 0.28 320)", tag: "Royal Velvet · Gold" },
  { name: "Neon Punjab", code: "NJ·002", price: "₹ 52,000", img: neon, glow: "oklch(0.78 0.18 210)", tag: "Phulkari · Reflective" },
  { name: "Holi Phantom", code: "NJ·003", price: "₹ 64,000", img: phantom, glow: "oklch(0.85 0.16 90)", tag: "Iridescent · Limited 99" },
];

export function Drops() {
  return (
    <section id="drops" className="relative py-32 overflow-hidden">
      <PowderClouds />
      <div className="mx-auto max-w-7xl px-6 lg:px-10 relative z-10">
        <div className="flex flex-col md:flex-row md:items-end md:justify-between mb-16 gap-6">
          <div>
            <p className="text-xs uppercase tracking-[0.5em] text-accent mb-4">Featured Drops</p>
            <h2 className="font-display text-5xl md:text-7xl leading-[0.9] max-w-2xl">
              Three souls. <span className="italic text-gradient">One festival.</span>
            </h2>
          </div>
          <p className="text-sm text-foreground/60 max-w-sm">
            Each silhouette is hand-numbered, dusted with gulal, and shipped in a velvet bandhani box.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {drops.map((d, i) => (
            <article
              key={d.code}
              className="group relative rounded-3xl overflow-hidden glass animate-fade-up hover:-translate-y-2 transition-transform duration-500"
              style={{ animationDelay: `${i * 0.15}s` }}
            >
              <div className="absolute -inset-px rounded-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"
                style={{ boxShadow: `0 0 80px -10px ${d.glow}, inset 0 0 60px -20px ${d.glow}` }}
              />
              <div className="relative aspect-[4/5] overflow-hidden">
                <div className="absolute inset-0 animate-pulse-glow" style={{
                  background: `radial-gradient(circle at 50% 60%, ${d.glow}, transparent 70%)`,
                  filter: "blur(40px)", opacity: 0.7,
                }} />
                <img
                  src={d.img}
                  alt={`${d.name} sneaker`}
                  loading="lazy"
                  className="relative w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  width={1024}
                  height={1280}
                />
                <div className="absolute top-4 left-4 px-3 py-1 rounded-full glass text-[10px] uppercase tracking-[0.3em]">
                  {d.code}
                </div>
              </div>
              <div className="p-6 flex items-end justify-between">
                <div>
                  <h3 className="font-display text-3xl">{d.name}</h3>
                  <p className="text-xs uppercase tracking-[0.3em] text-foreground/50 mt-2">{d.tag}</p>
                </div>
                <div className="text-right">
                  <p className="text-gold font-display text-xl">{d.price}</p>
                  <p className="text-[10px] uppercase tracking-[0.3em] text-foreground/50 mt-1">Reserve →</p>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
