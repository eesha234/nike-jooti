import { PowderClouds, Particles } from "./PowderClouds";
import { SneakerSpinner } from "./SneakerSpinner";

export function Hero() {
  return (
    <section id="top" className="relative min-h-screen w-full bg-hero overflow-hidden">
      <PowderClouds />
      <Particles count={50} />

      {/* faint gold ring behind shoe */}
      <div
        className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[80vmin] h-[80vmin] rounded-full animate-pulse-glow"
        style={{
          background:
            "conic-gradient(from 0deg, oklch(0.85 0.16 90 / 0.0), oklch(0.85 0.16 90 / 0.35), oklch(0.65 0.31 340 / 0.35), oklch(0.78 0.18 210 / 0.35), oklch(0.85 0.16 90 / 0.0))",
          filter: "blur(40px)",
        }}
      />

      <div className="relative z-10 mx-auto max-w-7xl px-6 lg:px-10 pt-40 pb-20 grid lg:grid-cols-12 gap-10 items-center min-h-screen">
        <div className="lg:col-span-5 animate-fade-up">
          <p className="text-xs uppercase tracking-[0.5em] text-accent mb-6">
            Vol·01 — Holi Edition
          </p>
          <h1 className="font-display text-[18vw] md:text-[10vw] lg:text-[7.5vw] leading-[0.85] tracking-tight">
            <span className="block text-foreground/95">NIKE</span>
            <span className="block italic text-gradient text-shadow-glow">× Jooti</span>
          </h1>
          <p className="mt-8 text-lg md:text-xl text-foreground/75 max-w-md font-light">
            Tradition reimagined through color. A futuristic fusion of sneaker culture
            and Indian jooti craftsmanship — painted by Holi.
          </p>

          <div className="mt-10 flex flex-wrap gap-4">
            <a
              href="#drops"
              className="group relative inline-flex items-center justify-center px-8 py-4 rounded-full text-sm uppercase tracking-[0.25em] font-medium overflow-hidden glow-pink"
              style={{ background: "linear-gradient(100deg, oklch(0.65 0.31 340), oklch(0.55 0.28 320))" }}
            >
              <span className="relative z-10">Explore the Drop</span>
              <span className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity"
                style={{ background: "linear-gradient(100deg, oklch(0.80 0.21 75), oklch(0.65 0.31 340))" }} />
            </a>
            <a
              href="#campaign"
              className="inline-flex items-center justify-center px-8 py-4 rounded-full text-sm uppercase tracking-[0.25em] glass hover:border-accent transition-colors"
            >
              ▶ Watch Campaign
            </a>
          </div>

          <div className="mt-14 flex items-center gap-8 text-xs uppercase tracking-[0.3em] text-foreground/50">
            <span>3 Silhouettes</span>
            <span className="h-px w-8 bg-foreground/30" />
            <span>Limited 999</span>
          </div>
        </div>

        <div className="lg:col-span-7 relative animate-fade-up" style={{ animationDelay: "0.3s" }}>
          <SneakerSpinner />
        </div>
      </div>

      {/* scroll cue */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 text-[10px] uppercase tracking-[0.4em] text-foreground/50 z-10">
        Scroll · Painted by Culture
      </div>
    </section>
  );
}
