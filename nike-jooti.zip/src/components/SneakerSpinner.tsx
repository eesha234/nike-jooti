import { useEffect, useMemo, useRef, useState } from "react";
import heroSneaker from "@/assets/hero-sneaker.png";

export function SneakerSpinner() {
  const ref = useRef<HTMLDivElement>(null);
  const [rotY, setRotY] = useState(-15);
  const [rotX, setRotX] = useState(8);
  const [rotZ, setRotZ] = useState(0);
  const [floatY, setFloatY] = useState(0);
  const [dragging, setDragging] = useState(false);
  const [autoSpin, setAutoSpin] = useState(true);
  const state = useRef({ x: 0, y: 0, rx: 8, ry: -15, vx: 0, vy: 0, last: 0, raf: 0, idleSince: performance.now() });

  // momentum + idle auto-spin loop
  useEffect(() => {
    const tick = () => {
      const s = state.current;
      const now = performance.now();
      const moving = Math.abs(s.vx) > 0.05 || Math.abs(s.vy) > 0.05;
      if (!dragging && moving) {
        s.ry += s.vx;
        s.rx = Math.max(-30, Math.min(30, s.rx + s.vy));
        s.vx *= 0.94;
        s.vy *= 0.94;
        setRotY(s.ry);
        setRotX(s.rx);
      } else if (!dragging && autoSpin && now - s.idleSince > 1200) {
        s.ry += 0.25;
        s.rx = 8 + Math.sin(now / 1800) * 6;
        setRotY(s.ry);
        setRotX(s.rx);
      }
      // continuous cinematic float + roll regardless of drag
      setFloatY(Math.sin(now / 1400) * 14);
      setRotZ(Math.sin(now / 2600) * 3);
      s.raf = requestAnimationFrame(tick);
    };
    state.current.raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(state.current.raf);
  }, [dragging, autoSpin]);

  const onDown = (e: React.PointerEvent) => {
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
    setDragging(true);
    const s = state.current;
    s.x = e.clientX; s.y = e.clientY;
    s.vx = 0; s.vy = 0;
    s.last = performance.now();
    s.idleSince = performance.now();
  };
  const onMove = (e: React.PointerEvent) => {
    if (!dragging) return;
    const s = state.current;
    const dx = e.clientX - s.x;
    const dy = e.clientY - s.y;
    s.x = e.clientX; s.y = e.clientY;
    s.ry += dx * 0.6;
    s.rx = Math.max(-30, Math.min(30, s.rx - dy * 0.4));
    s.vx = dx * 0.6;
    s.vy = -dy * 0.4;
    s.idleSince = performance.now();
    setRotY(s.ry);
    setRotX(s.rx);
  };
  const onUp = () => {
    setDragging(false);
    state.current.idleSince = performance.now();
  };

  // 3D orbiting powder particles
  const particles = useMemo(() => Array.from({ length: 18 }, (_, i) => {
    const angle = (i / 18) * Math.PI * 2;
    const radius = 38 + (i % 3) * 6;
    const colors = ["oklch(0.65 0.31 340)", "oklch(0.80 0.21 75)", "oklch(0.78 0.18 210)", "oklch(0.85 0.16 90)"];
    return {
      angle, radius,
      color: colors[i % colors.length],
      size: 6 + (i % 4) * 3,
      depth: -80 + (i % 5) * 40,
      delay: i * 0.18,
      duration: 6 + (i % 4) * 2,
    };
  }), []);

  return (
    <div
      ref={ref}
      onPointerDown={onDown}
      onPointerMove={onMove}
      onPointerUp={onUp}
      onPointerCancel={onUp}
      className="relative aspect-square select-none touch-none"
      style={{ perspective: "1400px", cursor: dragging ? "grabbing" : "grab" }}
    >
      {/* 3D orbital ring */}
      <div
        className="absolute inset-[12%] rounded-full pointer-events-none border border-accent/20"
        style={{
          transform: `rotateX(${75 + rotX * 0.3}deg) rotateZ(${rotY * 0.5}deg)`,
          transformStyle: "preserve-3d",
          boxShadow: "0 0 80px oklch(0.65 0.31 340 / 0.35) inset",
        }}
      />
      <div
        className="absolute inset-[20%] rounded-full pointer-events-none border border-[oklch(0.78_0.18_210)]/20"
        style={{
          transform: `rotateX(${70 + rotX * 0.2}deg) rotateY(${rotY * 0.3}deg) rotateZ(${-rotY * 0.4}deg)`,
          transformStyle: "preserve-3d",
        }}
      />

      {/* glow */}
      <div
        className="absolute inset-0 rounded-full animate-pulse-glow pointer-events-none"
        style={{
          background:
            "radial-gradient(circle at 50% 55%, oklch(0.65 0.31 340 / 0.6), oklch(0.80 0.21 75 / 0.3) 35%, transparent 70%)",
          filter: "blur(30px)",
        }}
      />

      {/* orbiting 3D particles */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          transformStyle: "preserve-3d",
          transform: `rotateX(${rotX * 0.6}deg) rotateY(${rotY * 0.6}deg)`,
        }}
      >
        {particles.map((p, i) => (
          <span
            key={i}
            className="absolute left-1/2 top-1/2 rounded-full"
            style={{
              width: p.size, height: p.size,
              background: p.color,
              filter: "blur(2px)",
              boxShadow: `0 0 14px ${p.color}`,
              transform: `translate3d(${Math.cos(p.angle) * p.radius}%, ${Math.sin(p.angle) * p.radius}%, ${p.depth}px)`,
              animation: `pulseGlow ${p.duration}s ease-in-out ${p.delay}s infinite`,
            }}
          />
        ))}
      </div>

      {/* sneaker with float + tilt + dynamic rim lighting */}
      {(() => {
        // Map rotation to a virtual light position
        const ny = Math.sin((rotY * Math.PI) / 180);
        const nx = Math.sin((rotX * Math.PI) / 180);
        const lightX = 50 - ny * 45; // 5..95
        const lightY = 50 - nx * 45;
        const rimX = 50 + ny * 55;
        const rimY = 50 + nx * 55;
        // Hue shift across the spin: saffron → magenta → cyan
        const t = (Math.sin((rotY * Math.PI) / 180) + 1) / 2;
        const keyColor = t < 0.5
          ? `oklch(0.85 0.22 ${75 + t * 200})`
          : `oklch(0.78 0.24 ${210 + (t - 0.5) * 260})`;
        const rimColor = `oklch(0.72 0.30 ${340 - ny * 120})`;
        const shadowColor = `oklch(0.65 0.31 ${340 - ny * 80} / 0.55)`;
        const maskStyle: React.CSSProperties = {
          WebkitMaskImage: `url(${heroSneaker})`,
          maskImage: `url(${heroSneaker})`,
          WebkitMaskSize: "contain",
          maskSize: "contain",
          WebkitMaskRepeat: "no-repeat",
          maskRepeat: "no-repeat",
          WebkitMaskPosition: "center",
          maskPosition: "center",
        };
        const sharedTransform = `translateY(${floatY}px) rotateX(${rotX}deg) rotateY(${rotY}deg) rotateZ(${rotZ}deg)`;
        const transition = dragging ? "none" : "transform 0.12s ease-out, filter 0.2s ease-out";
        return (
          <div
            className="absolute inset-0 z-10"
            style={{ transformStyle: "preserve-3d" }}
          >
            <img
              src={heroSneaker}
              alt="Nike × Jooti futuristic sneaker — drag to spin"
              draggable={false}
              className="absolute inset-0 w-full h-full object-contain"
              style={{
                transform: sharedTransform,
                transformStyle: "preserve-3d",
                transition,
                willChange: "transform, filter",
                filter: `drop-shadow(0 30px 80px ${shadowColor}) drop-shadow(0 0 30px ${rimColor.replace("0.30", "0.25")})`,
              }}
              width={1280}
              height={1280}
            />
            {/* Key light — bright highlight that follows rotation */}
            <div
              className="absolute inset-0 pointer-events-none mix-blend-screen"
              style={{
                ...maskStyle,
                transform: sharedTransform,
                transition,
                background: `radial-gradient(circle at ${lightX}% ${lightY}%, ${keyColor} 0%, transparent 35%)`,
                opacity: 0.7,
              }}
            />
            {/* Rim light — opposite side glow */}
            <div
              className="absolute inset-0 pointer-events-none mix-blend-screen"
              style={{
                ...maskStyle,
                transform: sharedTransform,
                transition,
                background: `radial-gradient(circle at ${rimX}% ${rimY}%, ${rimColor} 0%, transparent 28%)`,
                opacity: 0.85,
              }}
            />
            {/* Ambient shadow side */}
            <div
              className="absolute inset-0 pointer-events-none mix-blend-multiply"
              style={{
                ...maskStyle,
                transform: sharedTransform,
                transition,
                background: `radial-gradient(circle at ${100 - lightX}% ${100 - lightY}%, oklch(0.10 0.08 300 / 0.75) 0%, transparent 50%)`,
              }}
            />
            {/* Specular sweep — narrow moving streak */}
            <div
              className="absolute inset-0 pointer-events-none mix-blend-screen"
              style={{
                ...maskStyle,
                transform: sharedTransform,
                transition,
                background: `linear-gradient(${90 + rotY}deg, transparent ${Math.max(0, 40 - ny * 30)}%, oklch(0.98 0.05 90 / 0.55) ${50 - ny * 25}%, transparent ${Math.min(100, 60 - ny * 20)}%)`,
                opacity: 0.5 + Math.abs(ny) * 0.3,
              }}
            />
          </div>
        );
      })()}

      {/* ground shadow that reacts to float */}
      <div
        className="absolute left-1/2 -translate-x-1/2 bottom-[6%] rounded-[50%] pointer-events-none"
        style={{
          width: `${55 - floatY * 0.6}%`,
          height: `${10 - floatY * 0.15}%`,
          background: "radial-gradient(ellipse at center, oklch(0.05 0.05 300 / 0.7), transparent 70%)",
          filter: "blur(14px)",
          opacity: 0.7 - floatY * 0.01,
        }}
      />

      <span className="absolute top-4 left-0 text-[10px] uppercase tracking-[0.4em] text-accent/80 rotate-[-90deg] origin-left pointer-events-none">
        Air · Zardozi · Sole
      </span>
      <span className="absolute bottom-6 right-0 text-[10px] uppercase tracking-[0.4em] text-[oklch(0.78_0.18_210)]/80 pointer-events-none">
        Series·001 / Saffron Bloom
      </span>
      <span className="absolute -bottom-2 left-1/2 -translate-x-1/2 text-[10px] uppercase tracking-[0.4em] text-foreground/50 pointer-events-none">
        ⟲ Drag to spin · 3D preview
      </span>
      <button
        type="button"
        onClick={(e) => { e.stopPropagation(); setAutoSpin((v) => !v); }}
        onPointerDown={(e) => e.stopPropagation()}
        className="absolute top-4 right-0 text-[10px] uppercase tracking-[0.3em] glass px-3 py-1.5 rounded-full hover:border-accent transition-colors"
      >
        {autoSpin ? "❚❚ Pause 3D" : "▶ Auto-spin"}
      </button>
    </div>
  );
}
