import { PowderClouds } from "./PowderClouds";

export function Footer() {
  return (
    <footer id="footer" className="relative pt-32 pb-12 overflow-hidden border-t border-foreground/10">
      <PowderClouds />
      <div className="relative z-10 mx-auto max-w-7xl px-6 lg:px-10">
        <h2 className="font-display text-6xl md:text-9xl leading-[0.85] mb-16">
          Stay <span className="italic text-gradient">painted.</span>
        </h2>

        <div className="grid md:grid-cols-4 gap-10 mb-20">
          <div>
            <p className="text-[10px] uppercase tracking-[0.4em] text-accent mb-4">Follow</p>
            <ul className="space-y-2 text-foreground/80">
              <li><a href="#" className="hover:text-accent transition-colors">Instagram</a></li>
              <li><a href="#" className="hover:text-accent transition-colors">TikTok</a></li>
              <li><a href="#" className="hover:text-accent transition-colors">YouTube</a></li>
            </ul>
          </div>
          <div>
            <p className="text-[10px] uppercase tracking-[0.4em] text-accent mb-4">Explore</p>
            <ul className="space-y-2 text-foreground/80">
              <li><a href="#" className="hover:text-accent transition-colors">Lookbook</a></li>
              <li><a href="#" className="hover:text-accent transition-colors">Future Drops</a></li>
              <li><a href="#" className="hover:text-accent transition-colors">Atelier Stories</a></li>
            </ul>
          </div>
          <div>
            <p className="text-[10px] uppercase tracking-[0.4em] text-accent mb-4">Contact</p>
            <ul className="space-y-2 text-foreground/80">
              <li><a href="#" className="hover:text-accent transition-colors">Press</a></li>
              <li><a href="#" className="hover:text-accent transition-colors">Wholesale</a></li>
              <li><a href="#" className="hover:text-accent transition-colors">care@nikejooti.in</a></li>
            </ul>
          </div>
          <div>
            <p className="text-[10px] uppercase tracking-[0.4em] text-accent mb-4">Newsletter</p>
            <form className="flex glass rounded-full overflow-hidden p-1">
              <input type="email" placeholder="email@city.in" className="bg-transparent flex-1 px-4 py-2 text-sm placeholder:text-foreground/40 outline-none" />
              <button className="rounded-full px-4 py-2 text-xs uppercase tracking-[0.25em]" style={{ background: "linear-gradient(100deg, oklch(0.65 0.31 340), oklch(0.55 0.28 320))" }}>
                Join
              </button>
            </form>
          </div>
        </div>

        <div className="flex flex-col md:flex-row items-center justify-between gap-6 pt-8 border-t border-foreground/10">
          <p className="font-display italic text-2xl text-gradient">Designed in India. Painted by Culture.</p>
          <p className="text-xs uppercase tracking-[0.3em] text-foreground/40">© 2026 Nike × Jooti · A fictional collaboration</p>
        </div>
      </div>
    </footer>
  );
}
