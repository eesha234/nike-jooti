export function PowderClouds() {
  const clouds = [
    { c: "oklch(0.65 0.31 340)", top: "10%", left: "5%", size: 420, dur: "11s", delay: "0s" },
    { c: "oklch(0.80 0.21 75)", top: "60%", left: "75%", size: 500, dur: "13s", delay: "2s" },
    { c: "oklch(0.78 0.18 210)", top: "30%", left: "60%", size: 380, dur: "15s", delay: "1s" },
    { c: "oklch(0.55 0.28 320)", top: "75%", left: "10%", size: 460, dur: "17s", delay: "3s" },
    { c: "oklch(0.72 0.30 330)", top: "5%", left: "80%", size: 340, dur: "12s", delay: "4s" },
    { c: "oklch(0.85 0.16 90)", top: "85%", left: "50%", size: 360, dur: "14s", delay: "1.5s" },
  ];
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      {clouds.map((c, i) => (
        <div
          key={i}
          className="powder-cloud animate-float"
          style={{
            top: c.top,
            left: c.left,
            width: c.size,
            height: c.size,
            background: `radial-gradient(circle, ${c.c} 0%, transparent 70%)`,
            animationDuration: c.dur,
            animationDelay: c.delay,
          }}
        />
      ))}
    </div>
  );
}

export function Particles({ count = 40 }: { count?: number }) {
  const colors = [
    "oklch(0.80 0.21 75)",
    "oklch(0.65 0.31 340)",
    "oklch(0.78 0.18 210)",
    "oklch(0.85 0.16 90)",
    "oklch(0.72 0.30 330)",
  ];
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      {Array.from({ length: count }).map((_, i) => {
        const size = 2 + Math.random() * 4;
        return (
          <span
            key={i}
            className="absolute rounded-full animate-float-slow"
            style={{
              top: `${Math.random() * 100}%`,
              left: `${Math.random() * 100}%`,
              width: size,
              height: size,
              background: colors[i % colors.length],
              boxShadow: `0 0 ${size * 4}px ${colors[i % colors.length]}`,
              animationDuration: `${8 + Math.random() * 12}s`,
              animationDelay: `${Math.random() * 6}s`,
              opacity: 0.7,
            }}
          />
        );
      })}
    </div>
  );
}
