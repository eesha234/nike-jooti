import embroidery from "@/assets/texture-embroidery.jpg";
import burst from "@/assets/holi-burst.jpg";
import { Particles } from "./PowderClouds";

const captions = [
  { t: "Crafted in Culture", d: "Hand-spun zardozi threadwork from Lucknow ateliers, fused with Flyknit precision." },
  { t: "Powered by Color", d: "Pigments inspired by gulal — saffron, magenta, cyan and gold ignite every stitch." },
  { t: "Future of Tradition", d: "Reflective sole capsules that ripple light like wet color powder on marble." },
];

export function Craft() {
  return (
    <section id="craft" className="relative py-32 overflow-hidden">
      <Particles count={25} />
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        <div className="max-w-2xl mb-20">
          <p className="text-xs uppercase tracking-[0.5em] text-accent mb-4">The Craft</p>
          <h2 className="font-display text-5xl md:text-7xl leading-[0.95]">
            Where the <span className="italic text-gradient">loom</span> meets the <span className="italic text-gold">lab</span>.
          </h2>
        </div>

        <div className="grid lg:grid-cols-12 gap-6">
          <div className="lg:col-span-7 relative rounded-3xl overflow-hidden glass h-[460px]">
            <img src={embroidery} alt="Golden zardozi embroidery on violet silk dusted with magenta gulal" loading="lazy" className="absolute inset-0 w-full h-full object-cover" width={1280} height={800} />
            <div className="absolute inset-0 bg-gradient-to-t from-background via-background/30 to-transparent" />
            <div className="absolute bottom-8 left-8 right-8">
              <p className="text-[10px] uppercase tracking-[0.4em] text-accent mb-3">01 · Zardozi Atelier</p>
              <h3 className="font-display text-3xl md:text-4xl">{captions[0].t}</h3>
              <p className="mt-3 text-sm text-foreground/70 max-w-md">{captions[0].d}</p>
            </div>
          </div>

          <div className="lg:col-span-5 relative rounded-3xl overflow-hidden glass h-[460px]">
            <img src={burst} alt="Explosion of pink, saffron and cyan Holi color powder" loading="lazy" className="absolute inset-0 w-full h-full object-cover scale-110" width={1920} height={1080} />
            <div className="absolute inset-0 bg-gradient-to-t from-background via-background/40 to-transparent" />
            <div className="absolute bottom-8 left-8 right-8">
              <p className="text-[10px] uppercase tracking-[0.4em] text-[oklch(0.78_0.18_210)] mb-3">02 · Pigment Lab</p>
              <h3 className="font-display text-3xl md:text-4xl">{captions[1].t}</h3>
              <p className="mt-3 text-sm text-foreground/70">{captions[1].d}</p>
            </div>
          </div>

          <div className="lg:col-span-12 relative rounded-3xl overflow-hidden glass p-10 md:p-16 grid md:grid-cols-2 gap-10 items-center">
            <div>
              <p className="text-[10px] uppercase tracking-[0.4em] text-[oklch(0.85_0.16_90)] mb-4">03 · Engineered Sole</p>
              <h3 className="font-display text-4xl md:text-5xl mb-4">{captions[2].t}</h3>
              <p className="text-foreground/70 max-w-md">{captions[2].d}</p>
              <ul className="mt-8 grid grid-cols-2 gap-4 text-xs uppercase tracking-[0.25em] text-foreground/60">
                <li className="glass rounded-xl p-4">React Foam · Indigo</li>
                <li className="glass rounded-xl p-4">Gold Foil Swoosh</li>
                <li className="glass rounded-xl p-4">Silk Velvet Upper</li>
                <li className="glass rounded-xl p-4">Mirror Toe Cap</li>
              </ul>
            </div>
            <div className="relative aspect-square rounded-2xl overflow-hidden">
              <div className="absolute inset-0 animate-spin-slow" style={{
                background: "conic-gradient(from 0deg, oklch(0.65 0.31 340), oklch(0.80 0.21 75), oklch(0.78 0.18 210), oklch(0.65 0.31 340))",
                filter: "blur(30px)", opacity: 0.6,
              }} />
              <img src={embroidery} alt="" loading="lazy" className="relative w-full h-full object-cover rounded-2xl mix-blend-luminosity" width={1280} height={800} />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
