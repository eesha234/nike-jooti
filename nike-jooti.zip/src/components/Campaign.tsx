import campaign from "@/assets/campaign.jpg";

export function Campaign() {
  return (
    <section id="campaign" className="relative py-32 overflow-hidden">
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        <div className="grid lg:grid-cols-12 gap-10 items-end mb-12">
          <div className="lg:col-span-7">
            <p className="text-xs uppercase tracking-[0.5em] text-accent mb-4">The Campaign</p>
            <h2 className="font-display text-5xl md:text-7xl leading-[0.9]">
              A <span className="italic text-gradient">cinematic reel</span><br />painted in pigment.
            </h2>
          </div>
          <p className="lg:col-span-5 text-foreground/70 text-lg">
            Slow-motion bursts. Silk silhouettes. A shoe emerging from a saffron storm.
            Fashion week meets Indian festival energy.
          </p>
        </div>

        <div className="relative rounded-[2rem] overflow-hidden glass aspect-video group cursor-pointer">
          <img
            src={campaign}
            alt="Model walking through Holi color powder clouds wearing Nike × Jooti collection"
            loading="lazy"
            className="absolute inset-0 w-full h-full object-cover scale-105 group-hover:scale-110 transition-transform duration-1000"
            width={1920}
            height={1080}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/30 to-transparent" />

          {/* Play button */}
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="relative">
              <div className="absolute inset-0 rounded-full animate-pulse-glow" style={{
                background: "radial-gradient(circle, oklch(0.65 0.31 340 / 0.6), transparent 70%)", filter: "blur(20px)",
              }} />
              <button className="relative h-24 w-24 md:h-32 md:w-32 rounded-full glass flex items-center justify-center group-hover:scale-110 transition-transform duration-500 glow-pink">
                <span className="text-3xl ml-1">▶</span>
              </button>
            </div>
          </div>

          <div className="absolute bottom-8 left-8 right-8 flex flex-wrap gap-6 justify-between items-end">
            <div>
              <p className="text-[10px] uppercase tracking-[0.4em] text-accent mb-2">Reel · 02:48</p>
              <h3 className="font-display text-3xl md:text-5xl">Color Riot · Vol 01</h3>
            </div>
            <div className="flex gap-6 text-[10px] uppercase tracking-[0.3em] text-foreground/70">
              <span>Mumbai</span><span>Jaipur</span><span>Tokyo</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
