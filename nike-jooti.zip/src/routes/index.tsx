import { createFileRoute } from "@tanstack/react-router";
import { Nav } from "@/components/Nav";
import { Hero } from "@/components/Hero";
import { Marquee } from "@/components/Marquee";
import { Craft } from "@/components/Craft";
import { Drops } from "@/components/Drops";
import { Campaign } from "@/components/Campaign";
import { Footer } from "@/components/Footer";

export const Route = createFileRoute("/")({
  component: Index,
  head: () => ({
    meta: [
      { title: "NIKE × JOOTI — Tradition Reimagined Through Color" },
      { name: "description", content: "A futuristic luxury fusion of Nike sneaker culture and traditional Indian jooti craftsmanship, painted by the colors of Holi." },
      { property: "og:title", content: "NIKE × JOOTI · Holi Edition" },
      { property: "og:description", content: "Luxury cyberpunk India during Holi — three silhouettes painted by culture." },
    ],
    links: [
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      { rel: "stylesheet", href: "https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,500;1,400;1,500&family=Space+Grotesk:wght@300;400;500;700&display=swap" },
    ],
  }),
});

function Index() {
  return (
    <main className="relative">
      <Nav />
      <Hero />
      <Marquee />
      <Craft />
      <Drops />
      <Campaign />
      <Footer />
    </main>
  );
}
